
typedef unsigned int uint32_t;

typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long u64;

